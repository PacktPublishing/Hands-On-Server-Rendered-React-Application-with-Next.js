export default () => <h1>Welcome to nextjs</h1>;
