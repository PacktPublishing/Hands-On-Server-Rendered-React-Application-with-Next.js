const next = require('next');
const express = require('express');
const axios = require('axios');
const cookieParser = require('cookie-parser');

const dev = process.env.NODE_ENV !== 'production';
const PORT = process.env.PORT || 3000;
const app = next({ dev });
const handle = app.getRequestHandler();

const COOKIE_SECRET = 'ADAI1231s';
const COOKIE_OPTIONS = {
  httpOnly: true,
  secure: !dev,
  signed: true
};
const authenticate = async (email, password) => {
  const { data } = await axios.get(
    'https://jsonplaceholder.typicode.com/users'
  );
  return data.find(user => {
    if (user.email === email && user.website === password) {
      return user;
    }
  });
};

app.prepare().then(() => {
  const server = express();
  server.use(express.json());
  server.use(cookieParser(COOKIE_SECRET));

  server.post('/api/login', async (req, res) => {
    const { email, password } = req.body;
    const user = await authenticate(email, password);
    if (!user) {
      return res.status(401).send('Invalid credentials');
    }
    const userData = {
      name: user.name,
      email: user.email
    };
    res.cookie('token', userData, COOKIE_OPTIONS);
    return res.json(userData);
  });
  server.get('*', (req, res) => {
    return handle(req, res);
  });

  server.listen(PORT, err => {
    if (err) throw err;
    console.log(`App is running on PORT ${PORT}`);
  });
});
