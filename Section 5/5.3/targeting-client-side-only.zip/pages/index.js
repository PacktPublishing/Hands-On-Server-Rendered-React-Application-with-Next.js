import Layout from '../components/Layout/index';
import fetch from 'isomorphic-unfetch';
import Post from '../components/Posts/Post';

class Index extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      data: 'Jordan Belfort'
    };
  }
  //mock api call
  //ajax call
  getData() {
    setTimeout(() => {
      console.log('Our data is fetched');
      this.setState({
        data: 'Hello WallStreet'
      });
    }, 2000);
  }

  static async getInitialProps() {
    const res = await fetch(`${process.env.API_URL}/posts`);
    const posts = await res.json();
    // console.log(posts);
    return { posts };
  }
  componentDidMount() {
    this.getData();
    console.log('++ componentDidMount');
  }
  componentWillMount() {
    console.log('++ componentWillMount');
  }
  render() {
    const { posts } = this.props;
    return (
      <Layout>
        <div>{this.state.data}</div>
        {posts.map(post => (
          <Post key={post.id} {...post} />
        ))}
      </Layout>
    );
  }
}
export default Index;
