import Layout from '../components/Layout';

export default () => (
  <Layout>
    <h1> About Page</h1>
  </Layout>
);
