import Link from 'next/link';
import { logoutUser } from '../lib/auth';

const Layout = ({ title, children, auth }) => {
  const { user = {} } = auth || {};

  return (
    <div className="root">
      <nav className="navbar">
        <span>
          Welcome, <strong>{user.name || 'Guest'}</strong>
        </span>

        <div>
          <Link href="/">
            <a>Home</a>
          </Link>{' '}
          {user.email ? (
            // Auth Navigation
            <React.Fragment>
              <Link href="/profile">
                <a>Profile</a>
              </Link>{' '}
              <button onClick={logoutUser}>Logout</button>
            </React.Fragment>
          ) : (
            // UnAuth Navigation
            <Link href="/login">
              <a>Login</a>
            </Link>
          )}
        </div>
      </nav>

      <h1>{title}</h1>
      {children}

      <style jsx>{``}</style>
    </div>
  );
};

export default Layout;
