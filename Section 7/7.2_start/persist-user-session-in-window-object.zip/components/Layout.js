import Link from 'next/link';

const Layout = ({ title, children }) => {
  return (
    <div className="root">
      <nav className="navbar">
        <div>
          <Link href="/">
            <a>Home</a>
          </Link>{' '}
          <Link href="/profile">
            <a>Profile</a>
          </Link>{' '}
          <Link href="/logout">
            <a>Logout</a>
          </Link>{' '}
          <Link href="/login">
            <a>Login</a>
          </Link>
        </div>
      </nav>
      <h1>{title}</h1>
      {children}
    </div>
  );
};
export default Layout;
