import Link from 'next/link';

const Layout = ({ title, children, auth }) => {
  const { user = {} } = auth || {};
  return (
    <div className="root">
      <nav className="navbar">
        <span>
          Welcome <strong>{user.name || 'Guest'}</strong>
        </span>
        <div>
          <Link href="/">
            <a>Home</a>
          </Link>{' '}
          {user.email ? (
            <React.Fragment>
              <Link href="/profile">
                <a>Profile</a>
              </Link>{' '}
              <Link href="/logout">
                <a>Logout</a>
              </Link>{' '}
            </React.Fragment>
          ) : (
            <Link href="/login">
              <a>Login</a>
            </Link>
          )}
        </div>
      </nav>
      <h1>{title}</h1>
      {children}
    </div>
  );
};
export default Layout;
