import Footer from './Footer';
import Header from './Header';
import { Container } from 'reactstrap';
import Head from 'next/head';

export default ({ children }) => (
  <div>
    <Head>
      <title>Nextjs App</title>
      <meta name="viewport" content="initial-scale=1.0, width=device-width" />
      <link
        rel="stylesheet"
        href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
        integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T"
        crossorigin="anonymous"
      />
      <link rel="stylesheet" href="/static/styles.css" />
    </Head>
    <Header />
    <Container>{children}</Container>
    <Footer />
  </div>
);
