import Layout from '../components/Layout/index';
export default () => (
  <Layout>
    <h1>About Page</h1>
  </Layout>
);
