import Layout from '../components/Layout/index';

export default () => (
  <Layout>
    <h1>Welecom to Next.js</h1>
    <p>I am teaching Next.js</p>
  </Layout>
);
