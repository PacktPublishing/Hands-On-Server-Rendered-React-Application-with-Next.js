import Footer from './Footer';
import Header from './Header';
import { Container } from 'reactstrap';
import Head from 'next/head';

export default ({ children }) => (
  <div>
    <Head>
      <title>Nextjs App</title>
    </Head>
    <Header />
    <Container>{children}</Container>
    <Footer />
  </div>
);
